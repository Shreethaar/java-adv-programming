import java.time.Year;
import java.time.YearMonth;
import java.util.List;

public class PayrollSystemController {
    private SalesmanDatabaseModel dbModel;
    private PayrollSystemGUI view;

    public PayrollSystemController(PayrollSystemGUI view, SalesmanDatabaseModel dbModel) {
        this.view=view;
        this.dbModel=dbModel;
        initView();

    }

    private void initView() {
        view.getAddButton().addActionListener(e -> addSalesman());
        view.getSearchButton().addActionListener(e -> searchSalesman());
        view.getUpdateButton().addActionListener(e -> deleteSalesman());
        view.getResetButton().addActionListener(e -> resetSystem());
        view.getExitButton().addActionListenere(e -> exitSystem());
        view.getGenerateReportButton().addActionListenere(e -> generateReport());

    }

    private void addSalesman() {
        String fullName = view.getNameField().getText().trim();
        String staffNumber = view.getNameField().getText().trim();
        String icNumber = view.getIcNumberField().getText().trim();
        String bankAcc = view.getBankAccField().getText().trim();
        String totalSalesAmountStr = view.getTotalSalesField().getText().trim();
        String salesUnitStr = view.getSalesUnitField().getText().trim();
        String salaryMonthStr = view.getSalaryMonthField().getText().trim();
        String salaryYearStr = view.getSalaryYearField().getText().trim();

        try {
            double totalSalesAmount = Double.parseDouble(totalSalesAmountStr);
            int salesUnit = Integer.parseInt(salesUnitStr);
            int salaryMonth = Integer.parseInt(salaryMonthStr);
            int salaryYear = Integer.parseInt(salaryYearStr);

            YearMonth salaryMonthObj = YearMonth.of(salaryYear, salaryMonth);
            Year salaryYearObj = Year.of(salaryYear);

            SalesmanModel newSalesman = new SalesmanModel(fullName, staffNumber, icNumber, bankAcc, salesUnit, totalSalesAmount, salaryMonthObj, salaryYearObj, "");
            dbModel.addSalesman(newSalesman);

            view.displayMessage("Salesman added successfully.");
        } catch (NumberFormatException e) {
            view.displayMessage("Please enter valid numbers for Total Sales Amount, Number of Cars Sold, Salary Month, and Salary Year.");
        }
    }

    private void searchSalesman() {
        String fullName = view.getNameField().getText().trim();
        SalesmanModel salesman = dbModel.searchSalesmanByName(fullName);
        if(salesman!=null) {
            view.displaySalesmanInfo(salesman);
        }
        else {
            view.clearFields();
            view.displayMessage("Salesman not found");
        }
    }



    private void updateSalesman() {
        String fullName = view.getNameField().getText().trim();
        String staffNumber = view.getStaffNumberField().getText().trim();
        String icNumber = view.getIcNumberField().getText().trim();
        String bankAcc = view.getBankAccField().getText().trim();
        String totalSalesAmountStr = view.getTotalSalesField().getText().trim();
        String salesUnitStr = view.getSalesUnitField().getText().trim();
        String salaryMonthStr = view.getSalaryMonthField().getText().trim();
        String salaryYearStr = view.getSalaryYearField().getText().trim();

        try {
            double totalSalesAmount = Double.parseDouble(totalSalesAmountStr);
            int salesUnit = Integer.parseInt(salesUnitStr);
            int salaryMonth = Integer.parseInt(salaryMonthStr);
            int salaryYear = Integer.parseInt(salaryYearStr);

            YearMonth salaryMonthObj = YearMonth.of(salaryYear, salaryMonth);
            Year salaryYearObj = Year.of(salaryYear);

            SalesmanModel updatedSalesman = new SalesmanModel(fullName, staffNumber, icNumber, bankAcc, salesUnit, totalSalesAmount, salaryMonthObj, salaryYearObj, "");
            dbModel.editSalesman(updatedSalesman);

            view.displayMessage("Salesman updated successfully.");
        } catch (NumberFormatException e) {
            view.displayMessage("Please enter valid numbers for Total Sales Amount, Number of Cars Sold, Salary Month, and Salary Year.");
        }
    }

    private void deleteSalesman() {
        String staffNumber = view.getStaffNumberField().getText().trim();
        dbModel.deleteSalesman(staffNumber);
        view.clearFields();
        view.displayMessage("Salesman deleted successfully.");
    }

    private void resetSystem() {
        dbModel.reset();
        view.clearFields();
        view.displayMessage("System reset successfully.");
    }

    private void exitSystem() {
        System.exit(0);
    }

    private void generateReport() {
        // Change the report generation (with File I/O txt)
        String monthStr=view.getReportMonthField().getText().trim();
        String yearStr=view.getReportYearField().getText().trim();
        try{
            int month=Integer.parseInt(monthStr);
            int year=Integer.parseInt(yearStr);
            YearMonth reportMonth=YearMonth.of(year,month);
            List<SalesModel> reportData=dbModel.getSalesReport(reportMonth);
        }
        catch(NumberFormatException e) {
            view.displayMessage("Please enter valid numbers for Report Month and Report Year.");
        }
    }
}


